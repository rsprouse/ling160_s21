#ifndef RSTAN__RSTANINC_HPP
#define RSTAN__RSTANINC_HPP
#include <stan/math/prim/mat/fun/Eigen.hpp>
#include <rstan/stan_fit.hpp>
#endif

